import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class boxTest {

	Box box;
	@Before
	public void setUp() throws Exception {
		box = new Box (100, 100);
	}
	
}
